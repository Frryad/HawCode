const { app, BrowserWindow, ipcMain, dialog } = require('electron');
const path = require('path');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const chokidar = require('chokidar');
const localIpUrl = require('local-ip-url');
const fs = require('fs');
const os = require('os');
const dgram = require('dgram');
const { io: ioClient } = require('socket.io-client');

let mainWindow;
let sharedFolder = null;
let expressApp;
let server;
let io;
let watcher;
const PORT = 3000;
const UDP_PORT = 41234;
let localIp = localIpUrl('public', 'ipv4') || '127.0.0.1';

let remoteSocket = null;
let udpSocket = null;
let broadcastInterval = null;

const lastWrittenContent = new Map();
const recentLocalOps = new Map();
const discoveredWorkspaces = new Map();

function markRecentOp(relativePath) {
  if (!relativePath) return;
  const norm = relativePath.replace(/\\/g, '/').replace(/^\//, '');
  recentLocalOps.set(norm, Date.now());
}

function isRecentOp(relativePath) {
  if (!relativePath) return false;
  const norm = relativePath.replace(/\\/g, '/').replace(/^\//, '');
  const ts = recentLocalOps.get(norm);
  if (!ts) return false;
  if (Date.now() - ts < 2500) {
    return true;
  }
  recentLocalOps.delete(norm);
  return false;
}

function resolveSharedPath(relativePath) {
  if (!sharedFolder || typeof relativePath !== 'string' || relativePath.includes('\0')) {
    return null;
  }

  const root = path.resolve(sharedFolder);
  const normalizedPath = relativePath.replace(/^[/\\]+/, '');
  const resolved = path.resolve(root, normalizedPath);
  return resolved === root || resolved.startsWith(`${root}${path.sep}`) ? resolved : null;
}

function writeFileAndIgnore(filePath, relativePath, content) {
  const norm = relativePath.replace(/\\/g, '/').replace(/^\//, '');
  lastWrittenContent.set(norm, content);
  markRecentOp(norm);
  const dir = path.dirname(filePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(filePath, content, 'utf-8');
}

function deleteFileAndIgnore(filePath, relativePath) {
  const norm = relativePath.replace(/\\/g, '/').replace(/^\//, '');
  markRecentOp(norm);
  if (fs.existsSync(filePath)) {
    const stat = fs.statSync(filePath);
    if (stat.isDirectory()) {
      fs.rmSync(filePath, { recursive: true, force: true });
    } else {
      fs.unlinkSync(filePath);
    }
  }
}

function makeDirAndIgnore(filePath, relativePath) {
  const norm = relativePath.replace(/\\/g, '/').replace(/^\//, '');
  markRecentOp(norm);
  if (!fs.existsSync(filePath)) {
    fs.mkdirSync(filePath, { recursive: true });
  }
}

function notifyWindow(channel, data) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, data);
  }
}

function notifySyncStatus(status) {
  notifyWindow('sync-status', status);
}

function notifyDiscoveredWorkspaces() {
  if (mainWindow && !mainWindow.isDestroyed()) {
    const list = Array.from(discoveredWorkspaces.values());
    mainWindow.webContents.send('discovered-workspaces', list);
  }
}

function setupUdpDiscovery() {
  try {
    udpSocket = dgram.createSocket({ type: 'udp4', reuseAddr: true });

    udpSocket.on('error', (err) => {
      console.error('UDP socket error:', err);
    });

    udpSocket.on('message', (msg, rinfo) => {
      try {
        const data = JSON.parse(msg.toString());
        if (data.type === 'HAWCODE_WORKSPACE_BEACON' && data.url) {
          const isSelf = data.ip === localIp && data.port === PORT && sharedFolder;
          if (!isSelf) {
            discoveredWorkspaces.set(data.url, {
              ...data,
              lastSeen: Date.now()
            });
            notifyDiscoveredWorkspaces();
          }
        }
      } catch (e) {}
    });

    udpSocket.bind(UDP_PORT, () => {
      try {
        udpSocket.setBroadcast(true);
      } catch (e) {
        console.error('Error enabling UDP broadcast:', e);
      }
    });

    setInterval(() => {
      const now = Date.now();
      let changed = false;
      for (const [url, item] of discoveredWorkspaces.entries()) {
        if (now - item.lastSeen > 8000) {
          discoveredWorkspaces.delete(url);
          changed = true;
        }
      }
      if (changed) {
        notifyDiscoveredWorkspaces();
      }
    }, 3000);
  } catch (e) {
    console.error('Failed to initialize UDP discovery:', e);
  }
}

function startBroadcasting() {
  stopBroadcasting();
  if (!sharedFolder) return;

  broadcastInterval = setInterval(() => {
    if (!sharedFolder || !udpSocket) return;
    const payload = JSON.stringify({
      type: 'HAWCODE_WORKSPACE_BEACON',
      hostName: os.hostname(),
      folderName: path.basename(sharedFolder),
      ip: localIp,
      port: PORT,
      url: `http://${localIp}:${PORT}`
    });
    const message = Buffer.from(payload);
    try {
      udpSocket.send(message, 0, message.length, UDP_PORT, '255.255.255.255');
    } catch (e) {
      console.error('UDP broadcast send error:', e);
    }
  }, 3000);
}

function stopBroadcasting() {
  if (broadcastInterval) {
    clearInterval(broadcastInterval);
    broadcastInterval = null;
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 800,
    title: 'HawCode - Wi-Fi Collaborative Sync Editor',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
    }
  });

  const isDev = !app.isPackaged && process.argv.includes('--dev');
  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
  } else {
    mainWindow.loadFile(path.join(__dirname, 'dist', 'index.html'));
  }
}

function setupServer() {
  expressApp = express();
  server = http.createServer(expressApp);
  io = new Server(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const distPath = path.join(__dirname, 'dist');
  expressApp.use(express.static(distPath));
  expressApp.use(express.json());

  expressApp.get('/api/files', (req, res) => {
    if (!sharedFolder) return res.json({ error: 'No folder shared' });
    
    function getFiles(dir) {
      try {
        const subdirs = fs.readdirSync(dir);
        const files = [];
        for (const subdir of subdirs) {
          if (subdir.startsWith('.') || subdir === 'node_modules') continue;
          const resPath = path.resolve(dir, subdir);
          const stat = fs.statSync(resPath);
          if (stat.isDirectory()) {
            files.push({ name: subdir, type: 'directory', path: resPath.replace(sharedFolder, '').replace(/\\/g, '/').replace(/^\//, ''), children: getFiles(resPath) });
          } else {
            files.push({ name: subdir, type: 'file', path: resPath.replace(sharedFolder, '').replace(/\\/g, '/').replace(/^\//, '') });
          }
        }
        return files.sort((a, b) => {
          if (a.type === b.type) return a.name.localeCompare(b.name);
          return a.type === 'directory' ? -1 : 1;
        });
      } catch (e) {
        return [];
      }
    }
    
    try {
      res.json(getFiles(sharedFolder));
    } catch (e) {
      res.json({ error: e.message });
    }
  });

  expressApp.get('/api/file', (req, res) => {
    if (!sharedFolder) return res.json({ error: 'No folder shared' });
    if (!req.query.path) return res.json({ error: 'Path missing' });
    const filePath = resolveSharedPath(req.query.path);
    if (!filePath) return res.status(400).json({ error: 'Invalid path' });
    if (fs.existsSync(filePath)) {
      try {
        const content = fs.readFileSync(filePath, 'utf-8');
        res.json({ content });
      } catch (e) {
        res.status(500).json({ error: 'Cannot read file' });
      }
    } else {
      res.status(404).json({ error: 'File not found' });
    }
  });

  expressApp.put('/api/file', (req, res) => {
    if (!sharedFolder) return res.status(400).json({ error: 'No folder shared' });
    const relativePath = req.query.path || req.body?.path;
    const content = req.body?.content;
    const filePath = resolveSharedPath(relativePath);

    if (!filePath || typeof content !== 'string') {
      return res.status(400).json({ error: 'A valid path and string content are required' });
    }

    try {
      writeFileAndIgnore(filePath, relativePath, content);
      const update = { path: relativePath.replace(/\\/g, '/').replace(/^\//, ''), content };
      io.emit('file-updated', update);
      if (remoteSocket && remoteSocket.connected) remoteSocket.emit('file-edit', update);
      notifyWindow('file-updated', update);
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: 'Cannot write file' });
    }
  });

  io.on('connection', (socket) => {
    console.log('Client connected to host socket:', socket.id);
    notifySyncStatus({ peerConnected: true, activePeers: io.engine.clientsCount });

    socket.on('disconnect', () => {
      notifySyncStatus({ peerConnected: io.engine.clientsCount > 0, activePeers: io.engine.clientsCount });
    });

    socket.on('file-edit', (data) => {
      if (!sharedFolder || !data.path) return;
      try {
        const filePath = resolveSharedPath(data.path);
        if (!filePath || typeof data.content !== 'string') return;
        const currentContent = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf-8') : null;
        if (currentContent !== data.content) {
          writeFileAndIgnore(filePath, data.path, data.content);
          socket.broadcast.emit('file-updated', data);
          if (remoteSocket && remoteSocket.connected) {
            remoteSocket.emit('file-edit', data);
          }
          notifyWindow('file-updated', data);
        }
      } catch (e) {
        console.error('Error handling file-edit socket event:', e);
      }
    });

    socket.on('file-create', (data) => {
      if (!sharedFolder || !data.path) return;
      const filePath = resolveSharedPath(data.path);
      if (!filePath) return;
      try {
        writeFileAndIgnore(filePath, data.path, data.content || '');
        socket.broadcast.emit('file-created', data);
        if (remoteSocket && remoteSocket.connected) {
          remoteSocket.emit('file-create', data);
        }
        notifyWindow('file-tree-changed');
      } catch (e) {
        console.error('Error handling file-create:', e);
      }
    });

    socket.on('file-delete', (data) => {
      if (!sharedFolder || !data.path) return;
      const filePath = resolveSharedPath(data.path);
      if (!filePath) return;
      try {
        deleteFileAndIgnore(filePath, data.path);
        socket.broadcast.emit('file-deleted', data);
        if (remoteSocket && remoteSocket.connected) {
          remoteSocket.emit('file-delete', data);
        }
        notifyWindow('file-tree-changed');
      } catch (e) {
        console.error('Error handling file-delete:', e);
      }
    });

    socket.on('dir-create', (data) => {
      if (!sharedFolder || !data.path) return;
      const filePath = resolveSharedPath(data.path);
      if (!filePath) return;
      try {
        makeDirAndIgnore(filePath, data.path);
        socket.broadcast.emit('dir-created', data);
        if (remoteSocket && remoteSocket.connected) {
          remoteSocket.emit('dir-create', data);
        }
        notifyWindow('file-tree-changed');
      } catch (e) {
        console.error('Error handling dir-create:', e);
      }
    });

    socket.on('dir-delete', (data) => {
      if (!sharedFolder || !data.path) return;
      const filePath = resolveSharedPath(data.path);
      if (!filePath) return;
      try {
        deleteFileAndIgnore(filePath, data.path);
        socket.broadcast.emit('dir-deleted', data);
        if (remoteSocket && remoteSocket.connected) {
          remoteSocket.emit('dir-delete', data);
        }
        notifyWindow('file-tree-changed');
      } catch (e) {
        console.error('Error handling dir-delete:', e);
      }
    });
  });

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://${localIp}:${PORT}/`);
  });
}

function watchFolder(folderPath) {
  if (watcher) watcher.close();
  watcher = chokidar.watch(folderPath, {
    ignored: /(^|[\/\\])\..|node_modules/,
    persistent: true,
    ignoreInitial: true,
  });

  watcher
    .on('change', filePath => {
      const relativePath = filePath.replace(folderPath, '').replace(/\\/g, '/').replace(/^\//, '');
      if (isRecentOp(relativePath)) return;
      try {
        const content = fs.readFileSync(filePath, 'utf-8');
        if (lastWrittenContent.get(relativePath) === content) {
          return;
        }
        const data = { path: relativePath, content };
        io.emit('file-updated', data);
        if (remoteSocket && remoteSocket.connected) {
          remoteSocket.emit('file-edit', data);
        }
        notifyWindow('file-updated', data);
      } catch (e) {}
    })
    .on('add', filePath => {
      const relativePath = filePath.replace(folderPath, '').replace(/\\/g, '/').replace(/^\//, '');
      if (isRecentOp(relativePath)) return;
      try {
        const content = fs.readFileSync(filePath, 'utf-8');
        const data = { path: relativePath, content };
        io.emit('file-created', data);
        if (remoteSocket && remoteSocket.connected) {
          remoteSocket.emit('file-create', data);
        }
        notifyWindow('file-tree-changed');
      } catch (e) {}
    })
    .on('unlink', filePath => {
      const relativePath = filePath.replace(folderPath, '').replace(/\\/g, '/').replace(/^\//, '');
      if (isRecentOp(relativePath)) return;
      const data = { path: relativePath };
      io.emit('file-deleted', data);
      if (remoteSocket && remoteSocket.connected) {
        remoteSocket.emit('file-delete', data);
      }
      notifyWindow('file-tree-changed');
    })
    .on('addDir', filePath => {
      const relativePath = filePath.replace(folderPath, '').replace(/\\/g, '/').replace(/^\//, '');
      if (isRecentOp(relativePath)) return;
      const data = { path: relativePath };
      io.emit('dir-created', data);
      if (remoteSocket && remoteSocket.connected) {
        remoteSocket.emit('dir-create', data);
      }
      notifyWindow('file-tree-changed');
    })
    .on('unlinkDir', filePath => {
      const relativePath = filePath.replace(folderPath, '').replace(/\\/g, '/').replace(/^\//, '');
      if (isRecentOp(relativePath)) return;
      const data = { path: relativePath };
      io.emit('dir-deleted', data);
      if (remoteSocket && remoteSocket.connected) {
        remoteSocket.emit('dir-delete', data);
      }
      notifyWindow('file-tree-changed');
    });
}

async function syncAllFromHost(url, localFolder) {
  try {
    const res = await fetch(`${url}/api/files`);
    const tree = await res.json();
    if (tree.error) return;

    async function downloadTree(nodes) {
      for (const node of nodes) {
        if (node.type === 'directory') {
          const dirPath = path.join(localFolder, node.path);
          if (!fs.existsSync(dirPath)) {
            makeDirAndIgnore(dirPath, node.path);
          }
          if (node.children) {
            await downloadTree(node.children);
          }
        } else {
          const fileRes = await fetch(`${url}/api/file?path=${encodeURIComponent(node.path)}`);
          const fileData = await fileRes.json();
          if (fileData.content !== undefined) {
            const filePath = path.join(localFolder, node.path);
            writeFileAndIgnore(filePath, node.path, fileData.content);
          }
        }
      }
    }
    await downloadTree(tree);
    notifyWindow('file-tree-changed');
  } catch (e) {
    console.error('Failed to sync all from host:', e);
  }
}

app.whenReady().then(() => {
  setupServer();
  setupUdpDiscovery();
  createWindow();

  ipcMain.handle('select-folder', async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openDirectory']
    });
    
    if (!result.canceled) {
      sharedFolder = result.filePaths[0];
      if (remoteSocket) {
        remoteSocket.disconnect();
        remoteSocket = null;
      }
      watchFolder(sharedFolder);
      startBroadcasting();
      notifySyncStatus({ mode: 'host', localIp, port: PORT });
      return {
        folderPath: sharedFolder,
        networkUrl: `http://${localIp}:${PORT}`
      };
    }
    return null;
  });

  ipcMain.handle('join-workspace', async (event, url) => {
    const result = await dialog.showOpenDialog(mainWindow, {
      properties: ['openDirectory']
    });
    
    if (result.canceled) return null;
    
    const localFolder = result.filePaths[0];
    
    try {
      await syncAllFromHost(url, localFolder);
      
      if (remoteSocket) remoteSocket.disconnect();
      remoteSocket = ioClient(url, {
        reconnection: true,
        reconnectionAttempts: Infinity,
        reconnectionDelay: 1000
      });
      
      remoteSocket.on('connect', () => {
        notifySyncStatus({ mode: 'client', connectedToHost: true, hostUrl: url });
        syncAllFromHost(url, localFolder);
      });

      remoteSocket.on('disconnect', () => {
        notifySyncStatus({ mode: 'client', connectedToHost: false, hostUrl: url });
      });

      remoteSocket.on('file-updated', (data) => {
        if (!sharedFolder || !data.path) return;
        const filePath = resolveSharedPath(data.path);
        if (!filePath || typeof data.content !== 'string') return;
        writeFileAndIgnore(filePath, data.path, data.content);
        io.emit('file-updated', data);
        notifyWindow('file-updated', data);
      });
      
      remoteSocket.on('file-created', (data) => {
        if (!sharedFolder || !data.path) return;
        const filePath = resolveSharedPath(data.path);
        if (!filePath) return;
        writeFileAndIgnore(filePath, data.path, data.content || '');
        io.emit('file-tree-changed');
        notifyWindow('file-tree-changed');
      });

      remoteSocket.on('file-deleted', (data) => {
        if (!sharedFolder || !data.path) return;
        const filePath = resolveSharedPath(data.path);
        if (!filePath) return;
        deleteFileAndIgnore(filePath, data.path);
        io.emit('file-tree-changed');
        notifyWindow('file-tree-changed');
      });

      remoteSocket.on('dir-created', (data) => {
        if (!sharedFolder || !data.path) return;
        const filePath = resolveSharedPath(data.path);
        if (!filePath) return;
        makeDirAndIgnore(filePath, data.path);
        io.emit('file-tree-changed');
        notifyWindow('file-tree-changed');
      });

      remoteSocket.on('dir-deleted', (data) => {
        if (!sharedFolder || !data.path) return;
        const filePath = resolveSharedPath(data.path);
        if (!filePath) return;
        deleteFileAndIgnore(filePath, data.path);
        io.emit('file-tree-changed');
        notifyWindow('file-tree-changed');
      });

      remoteSocket.on('file-tree-changed', () => {
        io.emit('file-tree-changed');
        notifyWindow('file-tree-changed');
      });
      
      sharedFolder = localFolder;
      watchFolder(sharedFolder);
      startBroadcasting();

      return { 
        folderPath: sharedFolder,
        networkUrl: url,
        isClient: true
      };
      
    } catch (e) {
      console.error(e);
      return { error: 'Failed to connect to host: ' + e.message };
    }
  });

  ipcMain.handle('disconnect-workspace', async () => {
    if (watcher) {
      watcher.close();
      watcher = null;
    }
    if (remoteSocket) {
      remoteSocket.disconnect();
      remoteSocket = null;
    }
    stopBroadcasting();
    sharedFolder = null;
    notifySyncStatus({ mode: 'none' });
    return { ok: true };
  });

  ipcMain.handle('create-file', async (event, relativePath) => {
    if (!sharedFolder || !relativePath) return { error: 'No workspace active' };
    const filePath = resolveSharedPath(relativePath);
    if (!filePath) return { error: 'Invalid file path' };
    try {
      writeFileAndIgnore(filePath, relativePath, '');
      const data = { path: relativePath, content: '' };
      io.emit('file-created', data);
      if (remoteSocket && remoteSocket.connected) {
        remoteSocket.emit('file-create', data);
      }
      notifyWindow('file-tree-changed');
      return { ok: true };
    } catch (e) {
      return { error: e.message };
    }
  });

  ipcMain.handle('create-dir', async (event, relativePath) => {
    if (!sharedFolder || !relativePath) return { error: 'No workspace active' };
    const filePath = resolveSharedPath(relativePath);
    if (!filePath) return { error: 'Invalid directory path' };
    try {
      makeDirAndIgnore(filePath, relativePath);
      const data = { path: relativePath };
      io.emit('dir-created', data);
      if (remoteSocket && remoteSocket.connected) {
        remoteSocket.emit('dir-create', data);
      }
      notifyWindow('file-tree-changed');
      return { ok: true };
    } catch (e) {
      return { error: e.message };
    }
  });

  ipcMain.handle('delete-item', async (event, relativePath) => {
    if (!sharedFolder || !relativePath) return { error: 'No workspace active' };
    const filePath = resolveSharedPath(relativePath);
    if (!filePath) return { error: 'Invalid item path' };
    try {
      deleteFileAndIgnore(filePath, relativePath);
      const data = { path: relativePath };
      io.emit('file-deleted', data);
      if (remoteSocket && remoteSocket.connected) {
        remoteSocket.emit('file-delete', data);
      }
      notifyWindow('file-tree-changed');
      return { ok: true };
    } catch (e) {
      return { error: e.message };
    }
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
