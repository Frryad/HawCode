const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  selectFolder: () => ipcRenderer.invoke('select-folder'),
  joinWorkspace: (url) => ipcRenderer.invoke('join-workspace', url),
  disconnectWorkspace: () => ipcRenderer.invoke('disconnect-workspace'),
  createFile: (relativePath) => ipcRenderer.invoke('create-file', relativePath),
  createDir: (relativePath) => ipcRenderer.invoke('create-dir', relativePath),
  deleteItem: (relativePath) => ipcRenderer.invoke('delete-item', relativePath),
  onDiscoveredWorkspaces: (callback) => {
    const subscription = (event, workspaces) => callback(workspaces);
    ipcRenderer.on('discovered-workspaces', subscription);
    return () => ipcRenderer.removeListener('discovered-workspaces', subscription);
  },
  onSyncStatus: (callback) => {
    const subscription = (event, status) => callback(status);
    ipcRenderer.on('sync-status', subscription);
    return () => ipcRenderer.removeListener('sync-status', subscription);
  },
  onFileTreeChanged: (callback) => {
    const subscription = () => callback();
    ipcRenderer.on('file-tree-changed', subscription);
    return () => ipcRenderer.removeListener('file-tree-changed', subscription);
  },
  onFileUpdated: (callback) => {
    const subscription = (event, data) => callback(data);
    ipcRenderer.on('file-updated', subscription);
    return () => ipcRenderer.removeListener('file-updated', subscription);
  }
});

