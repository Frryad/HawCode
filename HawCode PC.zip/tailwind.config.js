/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        background: '#0f172a',
        foreground: '#f8fafc',
        primary: '#3b82f6',
        secondary: '#1e293b',
        accent: '#8b5cf6',
        border: '#334155'
      }
    },
  },
  plugins: [],
}
