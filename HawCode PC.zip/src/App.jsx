import React, { useState, useEffect } from 'react';
import Editor from '@monaco-editor/react';
import { io } from 'socket.io-client';
import { FolderOpen, File, Folder, Wifi, Server as ServerIcon, MonitorSmartphone, Circle, CheckCircle2 } from 'lucide-react';

const isElectron = window.electronAPI !== undefined;

export default function App() {
  const [networkUrl, setNetworkUrl] = useState('');
  const [sharedFolder, setSharedFolder] = useState('');
  const [fileTree, setFileTree] = useState([]);
  const [activeFile, setActiveFile] = useState(null);
  const [fileContent, setFileContent] = useState('');
  const [socket, setSocket] = useState(null);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [joinUrl, setJoinUrl] = useState('');
  const [isJoining, setIsJoining] = useState(false);
  const [joinError, setJoinError] = useState('');
  const [syncState, setSyncState] = useState('idle');

  // Initial Data Fetch
  useEffect(() => {
    if (!isElectron) {
      // Connect to the host's websocket
      const newSocket = io(window.location.origin);
      setSocket(newSocket);
      fetchFileTree();
      
      return () => newSocket.close();
    }
  }, []);

  const fetchFileTree = async () => {
    try {
      const baseUrl = isElectron ? 'http://localhost:3000' : window.location.origin;
      const res = await fetch(`${baseUrl}/api/files`);
      const data = await res.json();
      if (!data.error) {
        setFileTree(data);
      }
    } catch (e) {
      console.error('Failed to fetch file tree', e);
    }
  };

  useEffect(() => {
    if (socket) {
      socket.on('file-tree-changed', fetchFileTree);
      socket.on('file-updated', (data) => {
        if (activeFile === data.path) {
           setFileContent(data.content);
        }
        setSyncState('synced');
      });
      return () => {
        socket.off('file-tree-changed');
        socket.off('file-updated');
      }
    }
  }, [socket, activeFile]);

  // For Electron Host: Initialize Socket to localhost:3000 to listen for changes too
  useEffect(() => {
    if (isElectron && sharedFolder) {
       const hostSocket = io('http://localhost:3000');
       setSocket(hostSocket);
       hostSocket.on('file-tree-changed', fetchFileTree);
       hostSocket.on('file-updated', (data) => {
         if (activeFile === data.path) {
            setFileContent(data.content);
         }
         setSyncState('synced');
       });
       return () => hostSocket.close();
    }
  }, [activeFile, sharedFolder]);

  const handleSelectFolder = async () => {
    if (isElectron) {
      const result = await window.electronAPI.selectFolder();
      if (result) {
        setSharedFolder(result.folderPath);
        setNetworkUrl(result.networkUrl);
        fetchFileTree();
      }
    }
  };

  const handleJoinWorkspace = async () => {
    if (!joinUrl) return;
    setIsJoining(true);
    setJoinError('');
    try {
      const result = await window.electronAPI.joinWorkspace(joinUrl.trim());
      if (result && !result.error) {
        setSharedFolder(result.folderPath);
        setNetworkUrl(result.networkUrl);
        setShowJoinModal(false);
        fetchFileTree();
      } else if (result && result.error) {
        setJoinError(result.error);
      }
    } catch (e) {
      setJoinError(e.message || 'Connection failed');
    }
    setIsJoining(false);
  };

  const openFile = async (path) => {
    try {
      const baseUrl = isElectron ? 'http://localhost:3000' : window.location.origin;
      const res = await fetch(`${baseUrl}/api/file?path=${encodeURIComponent(path)}`);
      const data = await res.json();
      if (!data.error) {
        setActiveFile(path);
        setFileContent(data.content);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleEditorChange = (value) => {
    setFileContent(value);
    setSyncState('syncing');
    if (socket && activeFile) {
      socket.emit('file-edit', { path: activeFile, content: value });
    }
  };

  const syncLabel = syncState === 'syncing' ? 'Syncing changes' : syncState === 'synced' ? 'All changes synced' : 'Ready to sync';

  const renderTree = (nodes) => {
    return nodes.map((node, i) => (
      <div key={i} className="pl-4 mt-1">
        {node.type === 'directory' ? (
          <div className="">
            <div className="flex items-center gap-2 text-slate-300 py-1 font-medium">
              <Folder size={16} className="text-indigo-400" />
              <span>{node.name}</span>
            </div>
            {node.children && renderTree(node.children)}
          </div>
        ) : (
          <div 
            className={`flex items-center gap-2 py-1.5 px-2 rounded-md cursor-pointer transition-colors ${activeFile === node.path ? 'bg-indigo-500/20 text-indigo-300 font-medium' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
            onClick={() => openFile(node.path)}
          >
            <File size={16} className={activeFile === node.path ? 'text-indigo-400' : 'text-slate-500'} />
            <span className="truncate">{node.name}</span>
          </div>
        )}
      </div>
    ));
  };

  if (isElectron && !sharedFolder) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-background text-foreground relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
        
        <div className="max-w-md w-full bg-secondary/80 backdrop-blur-xl p-10 rounded-3xl shadow-2xl border border-white/10 text-center space-y-8 z-10">
          <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg shadow-indigo-500/30 transform rotate-3">
             <ServerIcon size={48} className="text-white transform -rotate-3" />
          </div>
          <div className="space-y-3">
            <h1 className="text-5xl font-extrabold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-blue-400 via-indigo-400 to-purple-500">
              HawCode
            </h1>
            <p className="text-slate-400 text-sm leading-relaxed">
              Share a local folder over Wi-Fi instantly. Collaborate in real-time with any device on your network without complex setup.
            </p>
          </div>
          <div className="flex flex-col gap-3 w-full">
            <button 
              onClick={handleSelectFolder}
              className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-indigo-500 to-blue-600 hover:from-indigo-400 hover:to-blue-500 text-white py-4 px-6 rounded-xl font-bold transition-all shadow-lg shadow-indigo-500/25 hover:shadow-indigo-500/40 hover:-translate-y-0.5"
            >
              <FolderOpen size={22} />
              Host Workspace
            </button>
            <button 
              onClick={() => setShowJoinModal(true)}
              className="w-full flex items-center justify-center gap-3 bg-white/5 hover:bg-white/10 text-white py-4 px-6 rounded-xl font-bold transition-all border border-white/10 hover:border-white/20"
            >
              <Wifi size={22} />
              Join Workspace
            </button>
          </div>
        </div>

        {showJoinModal && (
          <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
            <div className="bg-[#161b22] border border-white/10 p-6 rounded-2xl w-full max-w-md shadow-2xl">
              <h3 className="text-xl font-bold text-white mb-2">Join Workspace</h3>
              <p className="text-slate-400 text-sm mb-4">Enter the Host URL to connect and sync files locally.</p>
              
              <input
                type="text"
                placeholder="http://192.168.1.x:3000"
                value={joinUrl}
                onChange={(e) => setJoinUrl(e.target.value)}
                className="w-full bg-[#0d1117] border border-white/10 rounded-lg px-4 py-3 text-white mb-2 focus:outline-none focus:border-indigo-500"
              />
              {joinError && <p className="text-red-400 text-xs mb-4">{joinError}</p>}
              
              <div className="flex gap-3 mt-6">
                <button 
                  onClick={() => setShowJoinModal(false)}
                  className="flex-1 py-2.5 px-4 rounded-lg bg-white/5 hover:bg-white/10 text-white font-medium transition-colors"
                >
                  Cancel
                </button>
                <button 
                  onClick={handleJoinWorkspace}
                  disabled={isJoining || !joinUrl}
                  className="flex-1 py-2.5 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-medium transition-colors flex items-center justify-center gap-2"
                >
                  {isJoining ? 'Connecting...' : 'Connect'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  const getLanguage = (filename) => {
    if (!filename) return 'javascript';
    const ext = filename.split('.').pop().toLowerCase();
    const map = {
      'js': 'javascript', 'jsx': 'javascript', 'ts': 'typescript', 'tsx': 'typescript',
      'json': 'json', 'html': 'html', 'css': 'css', 'md': 'markdown', 'py': 'python',
      'java': 'java', 'c': 'c', 'cpp': 'cpp', 'rs': 'rust', 'go': 'go'
    };
    return map[ext] || 'plaintext';
  };

  return (
    <div className="flex h-screen bg-background text-foreground overflow-hidden font-sans">
      {/* Sidebar */}
      <div className="w-72 flex-shrink-0 bg-[#161b22] border-r border-border flex flex-col shadow-xl z-10 relative">
        <div className="p-5 border-b border-white/5 bg-[#161b22]">
          <h2 className="font-bold text-lg bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-indigo-400 flex items-center gap-2">
            <ServerIcon size={20} className="text-blue-400" />
            HawCode
          </h2>
          {isElectron && sharedFolder && (
            <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-3" aria-live="polite">
              {syncState === 'syncing' ? <Circle size={10} className="text-amber-400 animate-pulse" /> : <CheckCircle2 size={13} className="text-emerald-400" />}
              {syncLabel}
            </div>
          )}
          {!isElectron && (
            <span className="text-xs text-green-400 mt-1 block font-medium">Connected to Host</span>
          )}
        </div>
        <div className="flex-1 overflow-y-auto p-3 text-sm custom-scrollbar">
          {fileTree.length > 0 ? renderTree(fileTree) : (
            <div className="text-center text-slate-500 mt-10 p-4">
              <FolderOpen size={32} className="mx-auto mb-2 opacity-50" />
              {isElectron ? "Empty Folder" : "Waiting for files..."}
            </div>
          )}
        </div>
        {isElectron && networkUrl && (
          <div className="p-5 bg-[#0d1117] border-t border-white/5 mt-auto">
            <div className="flex items-center gap-2 text-[10px] text-slate-400 mb-3 font-bold uppercase tracking-widest">
              <Wifi size={12} className="text-green-400" />
              Wi-Fi Sharing Active
            </div>
            <div className="bg-white/5 border border-white/10 p-3 rounded-xl flex items-center gap-3 shadow-inner">
              <div className="bg-blue-500/20 p-2 rounded-lg">
                <MonitorSmartphone size={20} className="text-blue-400 flex-shrink-0" />
              </div>
              <div className="overflow-hidden">
                <p className="text-xs text-slate-400 truncate mb-0.5">Access on other devices:</p>
                <a href={networkUrl} target="_blank" rel="noreferrer" className="text-sm text-green-400 hover:text-green-300 font-mono font-medium truncate block transition-colors">
                  {networkUrl}
                </a>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col bg-[#0d1117]">
        {activeFile ? (
          <>
            <div className="h-12 border-b border-border bg-[#161b22] flex items-center px-4 flex-shrink-0 shadow-sm z-10">
              <div className="flex items-center gap-2 bg-[#0d1117] px-4 py-1.5 rounded-t-md border border-b-0 border-white/10 translate-y-[1px]">
                <File size={14} className="text-indigo-400" />
                <span className="text-sm font-medium text-slate-200">{activeFile.split('/').pop()}</span>
              </div>
            </div>
            <div className="flex-1 relative">
              <Editor
                height="100%"
                language={getLanguage(activeFile)}
                theme="vs-dark"
                value={fileContent}
                onChange={handleEditorChange}
                options={{
                  minimap: { enabled: false },
                  fontSize: 14,
                  fontFamily: "'JetBrains Mono', 'Fira Code', Consolas, monospace",
                  wordWrap: 'on',
                  padding: { top: 20 },
                  scrollBeyondLastLine: false,
                  smoothScrolling: true,
                  cursorBlinking: 'smooth',
                  cursorSmoothCaretAnimation: 'on',
                  formatOnPaste: true,
                  renderLineHighlight: 'all',
                }}
              />
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-600 bg-gradient-to-b from-[#0d1117] to-[#161b22]">
            <div className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mb-6">
              <File size={40} className="text-slate-500" />
            </div>
            <h3 className="text-xl font-medium text-slate-300 mb-2">No File Selected</h3>
            <p className="text-sm text-slate-500 max-w-sm text-center">Select a file from the sidebar to start collaborating in real-time.</p>
          </div>
        )}
      </div>
    </div>
  );
}
