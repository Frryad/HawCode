# HawCode

HawCode is an Electron code editor that shares a selected workspace over the local Wi-Fi network.

## Use

1. Run `npm install`, then `npm start`.
2. In the desktop app, choose `Host Workspace` and select the folder to share.
3. Open the displayed Wi-Fi URL on another computer or phone connected to the same network.
4. Select files in the browser editor. Changes are written to the shared folder and broadcast to connected HawCode clients.
5. On another desktop installation, choose `Join Workspace` and enter the host URL. HawCode downloads the folder and keeps it synchronized.

The server only serves and writes files inside the selected workspace. Hidden files and `node_modules` are excluded from the shared tree.

## Development

This template provides a minimal setup to get React working in Vite with HMR and some Oxlint rules.

Currently, two official plugins are available:

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react) uses [Oxc](https://oxc.rs)
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react-swc) uses [SWC](https://swc.rs/)

## React Compiler

The React Compiler is not enabled on this template because of its impact on dev & build performances. To add it, see [this documentation](https://react.dev/learn/react-compiler/installation).

## Expanding the Oxlint configuration

If you are developing a production application, we recommend using TypeScript with type-aware lint rules enabled. Check out the [TS template](https://github.com/vitejs/vite/tree/main/packages/create-vite/template-react-ts) for information on how to integrate TypeScript and Oxlint's TypeScript related rules in your project.
